# -*- coding: utf-8 -*-

from .gui import run

run()